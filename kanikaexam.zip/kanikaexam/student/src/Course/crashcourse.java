package Course;

public class crashcourse {
        String name;
        int duration;
        int fee;
		
        
        crashcourse() {
			//super();
			this.name ="Gate";
			this.duration = 6;
        }//method overloading
       
        
        
        
        
        //constructor overloading
		 public crashcourse(String name, int duration) {
		 this.name = name;
		 this.duration = 12;
		 }
		 void display() {
			 System.out.println("course details\nCourseName:" +name+"\t Duration:"+duration+"\n"); ;
		 }
		 public static void main(String args[]) {
			 crashcourse c1=new crashcourse();
			 c1.display();
			 crashcourse c2=new crashcourse("Neet",12);
			 c2.display();
			 
		 }
}

		 


     