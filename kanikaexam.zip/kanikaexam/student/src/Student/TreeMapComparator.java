	
		

package Student;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.concurrent.*;
public class Student {
	
	public static void main(String[] args)
    {
		HashMap<String, String> map = new HashMap<>();
		
		map.put("kanika", "B.tech");
        map.put("john", "BSC");
        map.put("riya", "Bcom");
        System.out.println(map);
        
        if (map.containsKey("kanika")) {
        	 String a = map.get("kanika");
        	 System.out.println("value for key"
                     + " \"kanika\" is:- " + a);
        	 
        	 
        	 //class Sortbybirthdate implements Comparator<Student> {
        	 
        	 

}
	
	        TreeMap<String, String> tree_map= new TreeMap<String, String>();
//	            
	        
	        tree_map.put("kanika", "Geeks");
	        tree_map.put("john", "4");
	        tree_map.put("riya", "Geeks");
	        System.out.println("TreeMap: " + tree_map);
}
}

	        
    
	
	


        	

 